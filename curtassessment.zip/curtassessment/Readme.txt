How to run the Prime numbers generator:

1). Makes sure you load all the files in one folder, call it xxxxx where PHP is executable

2). Invoke the index.php file in the folder xxxxx

3) Once the index.php file is loaded 

4) Clicked on the green button (Generate Prime Numbers between 2 - 1000) 

5) It will generate and display Prime numbers from 2 to 1000 on the browser screen.