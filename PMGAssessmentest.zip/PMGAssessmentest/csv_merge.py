#!/usr/bin/env python

# Python 3.x version

import pandas as pd
from IPython.display import display
from IPython.display import Image

# To merge the CSV files
# dataset for the household_cleaners.csv
raw_data = {
		'email_hash': ['b9f6f22276c919da793da65c76345ebb0b072257d12402107d09c89bc369a6b6','00449a86bb34e443a5f84635661f63514574a030a15e2e57b81b2c3f4fa49650','b9f6f22276c919da793da65c76345ebb0b072257d12402107d09c89bc369a6b6','c2b5fa9e09ef2464a2b9ed7e351a5e1499823083c057913c6995fdf4335c73e7','faaee0ff7d06b05313ecb75d46a9aed014b11023ca1af5ec21a0607848071d18','00449a86bb34e443a5f84635661f63514574a030a15e2e57b81b2c3f4fa49650',],
		'category':	  ['Kitchen Cleaner','Bathroom Cleaner','Kitchen Cleaner','Kitchen Cleaner','Kitchen Cleaner','Bathroom Cleaner',]}
df_a = pd.DataFrame(raw_data, colums = ['email_hash','category'])	
df_a

# dataset for the accessories.csv
raw_data = {
        'email_hash': ['00449a86bb34e443a5f84635661f63514574a030a15e2e57b81b2c3f4fa49650', 'b9f6f22276c919da793da65c76345ebb0b072257d12402107d09c89bc369a6b6', 'c2b5fa9e09ef2464a2b9ed7e351a5e1499823083c057913c6995fdf4335c73e7', 'faaee0ff7d06b05313ecb75d46a9aed014b11023ca1af5ec21a0607848071d18', '5cd72da5035f2b36b604a16efc639cd04b6cfae7e487dcba60db88d3ef870f1e'],
        'category': ['Satchels', 'Purses', 'Purses', 'Wallets', 'Purses']}
df_b = pd.DataFrame(raw_data, columns = ['email_hash', 'category'])
df_b	


# dataset for the clothing.csv
raw_data = {
        'email_hash': ['00449a86bb34e443a5f84635661f63514574a030a15e2e57b81b2c3f4fa49650', 'b9f6f22276c919da793da65c76345ebb0b072257d12402107d09c89bc369a6b6', 'c2b5fa9e09ef2464a2b9ed7e351a5e1499823083c057913c6995fdf4335c73e7', 'faaee0ff7d06b05313ecb75d46a9aed014b11023ca1af5ec21a0607848071d18', '5cd72da5035f2b36b604a16efc639cd04b6cfae7e487dcba60db88d3ef870f1e'],
        'category': ['Blouses', 'Shirts', 'Shirts', 'Cardigans', 'Capris']}
df_c = pd.DataFrame(raw_data, columns = ['email_hash', 'category'])
df_c


# dataset for the clothing.csv
raw_data = {
        'email_hash': ['00449a86bb34e443a5f84635661f63514574a030a15e2e57b81b2c3f4fa49650', 'b9f6f22276c919da793da65c76345ebb0b072257d12402107d09c89bc369a6b6', 'c2b5fa9e09ef2464a2b9ed7e351a5e1499823083c057913c6995fdf4335c73e7', 'faaee0ff7d06b05313ecb75d46a9aed014b11023ca1af5ec21a0607848071d18', '5cd72da5035f2b36b604a16efc639cd04b6cfae7e487dcba60db88d3ef870f1e'],
        'category': ['Shirts', 'Pants', 'Cardigans', 'Wallets', 'Purses'],
		'filename': ['clothing.csv', 'clothing.csv', 'clothing.csv', '	clothing.csv', 'accessories.csv']}
df_new_column = pd.DataFrame(raw_data, columns = ['email_hash', 'category', 'filename'])
df_new_column


#Merge two dataframes along the subject_id value
pd.merge(df_new, df_n, on='filename')


